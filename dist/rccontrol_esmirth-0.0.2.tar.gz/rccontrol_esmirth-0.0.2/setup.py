from setuptools import setup

setup(
    name = "RCControl_ESmirth",
    version = "0.0.2",
    author = "E Smirthwaite", 
    author_email="nqn524@york.ac.uk",
    dependencies = [
        "picozero",
        "microdot"
    ],
    data_files = [
        "RCControl/website/index.html",
        "RCControl/website/joystick.js"
    ]
)