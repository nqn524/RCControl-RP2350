from setuptools import setup

setup(
    name = "RCControl_ESmirth",
    description = "Library to make it easier to wirelessly connect a Raspberry PI Pico 2 W using Bluetooth Low Energy or WiFi making use of websockets",
    readme = "README.md",
    long_description_content_type = "text/markdown",
    version = "0.3",
    author = "E Smirthwaite", 
    author_email="nqn524@york.ac.uk",
    url = "https://github.com/nqn524/RCControl-RP2350",
    dependencies = [
        "picozero",
        "microdot"
    ],
    data_files = [
        "RCControl/website/index.html",
        "RCControl/website/joystick.js"
    ],
    license = "MIT",
    license_files = "LICENSE"
)